SISTEMA DE CÁMARAS - INSTALACIÓN WINDOWS
========================================

📁 Archivo principal: INSTALACION_WINDOWS.md

🚀 PASOS RÁPIDOS:

1. Instalar software base (30 min):
   - Git for Windows
   - Python 3.10+
   - Node.js
   - FFmpeg
   - Tailscale

2. Clonar proyecto en C:\titulo

3. Configurar entorno Python

4. Configurar .env

5. Ejecutar: INICIAR_SISTEMA_WINDOWS.bat

📝 Ver guía completa en: INSTALACION_WINDOWS.md

⏱️ Tiempo total: ~90 minutos
✅ Resultado: Sistema 24/7 sin dependencia del Mac
